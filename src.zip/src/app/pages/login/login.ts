import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth';
import { Router } from '@angular/router';
import { RouterModule } from '@angular/router';   
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, RouterModule], 
  templateUrl: './login.html'
})
export class LoginComponent {

  user = {
    email: '',
    password: ''
  };

  constructor(private api: ApiService, private router: Router) {}
login() {
  this.api.getUsers().subscribe((users: any) => {

    const foundUser = users.find(
      (u: any) =>
        u.email === this.user.email &&
        u.password === this.user.password
    );

    if (foundUser) {

      console.log("LOGIN SUCCESS:", foundUser);

      localStorage.setItem('user', JSON.stringify(foundUser));

      if (foundUser.role === 'admin') {
        this.router.navigate(['/admin']);
      } else {
        this.router.navigate(['/student']);
      }

    } else {
      alert("Invalid login");
    }
  });
}


}