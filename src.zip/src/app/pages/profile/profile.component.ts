import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './profile.html'
})
export class StudentProfileComponent {

  user: any = {};
  editMode = false;

  constructor(private api: ApiService) {
    this.user = JSON.parse(localStorage.getItem('user') || '{}');
  }

updateProfile() {
  this.api.updateUser(this.user.id, this.user).subscribe({
    next: () => {
      alert("✅ Profile updated");
      localStorage.setItem('user', JSON.stringify(this.user));
      this.editMode = false;
    },
    error: (err) => {
      console.error("❌ UPDATE ERROR:", err.error);
      alert(JSON.stringify(err.error)); 
    }
  });
}
}