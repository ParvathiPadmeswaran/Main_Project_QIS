import { Component, NgZone, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-student-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './student-dashboard.html'
})
export class StudentDashboardComponent implements OnDestroy {

  exams: any[] = [];
  filteredQuestions: any[] = [];

  selectedExam: any = null;
  answers: any = {};

  timeLeft: number = 0;
  timer: any;

  result: any = null;
  history: any[] = [];

  currentQuestionIndex: number = 0;
  Math = Math;

  selectedMenu: string = 'home';
  examTypes = ['Practice', 'Mid', 'Model', 'Final', 'Easy', 'Medium', 'Hard'];
  completedExams: string[] = [];
  filteredExamList: any[] = [];
  selectedResultExam: string | null = null;
  groupedResults: any = {};

  maxAttempts = 3;

  currentUser: any = {};
  userId: number | null = null;

constructor(
  private api: ApiService,
  private zone: NgZone,
  private cd: ChangeDetectorRef
) {
  this.loadData();
  // this.loadResults();
  this.currentUser = JSON.parse(localStorage.getItem('user') || '{}');
  this.userId = this.currentUser?.id || null;
}

loadData() {

  this.api.getExams().subscribe({
    next: (res: any) => {

      this.exams = res || [];

      console.log("EXAMS LOADED:", this.exams);

      this.loadResults();

      this.cd.detectChanges();
    },
    error: (err) => {
      console.error("Error loading exams:", err);
    }
  });

}


selectExam(exam: any) {
   if (!this.canAttemptExam(exam)) {
    alert("❌ Maximum attempts (3) reached for this exam!");
    return;
  }

  this.selectedExam = exam;

  this.filteredQuestions = (exam.questions || []).map((q: any) => ({
    id: q.id,
    text: q.question_text,


    options: [
      q.option_a,
      q.option_b,
      q.option_c,
      q.option_d
    ],

    correctAnswer: q.correct_answer,
    marks: q.marks
  }));

  console.log("QUESTIONS:", this.filteredQuestions); // ✅ DEBUG

  this.currentQuestionIndex = 0;

  this.startTimer(exam.duration);
}


selectOption(qId: number, option: string) {

  if (this.answers[qId] === option) {
    delete this.answers[qId];  
  } else {
    this.answers[qId] = option;
  }
}


startTimer(minutes: number) {

  if (this.timer) clearInterval(this.timer);

  this.timeLeft = Number(minutes) * 60;

  this.timer = setInterval(() => {

    if (this.timeLeft <= 0) {

      clearInterval(this.timer);
      this.timeLeft = 0;

      this.zone.run(() => {
        this.submitExam();   
      });

      return; 
    }

    this.timeLeft--;

    this.zone.run(() => {
      this.cd.detectChanges();
    });

  }, 1000);
}

  nextQuestion() {
    if (this.currentQuestionIndex < this.filteredQuestions.length - 1) {
      this.currentQuestionIndex++;
    }
  }

  prevQuestion() {
    if (this.currentQuestionIndex > 0) {
      this.currentQuestionIndex--;
    }
  }


submitExam() {

  console.log("🔥 SUBMIT CLICKED");

  if (this.timer) {
    clearInterval(this.timer);
  }

  let score = 0;
  let totalMarks = 0;

  
  this.filteredQuestions.forEach(q => {

    totalMarks += Number(q.marks || 1);

    if (this.answers[q.id] === q.correctAnswer) {
      score += Number(q.marks || 1);
    }

  });

  if (totalMarks === 0) {
    alert("No questions!");
    return;
  }

  const percentage = (score / totalMarks) * 100;
  let rank = '';
let suggestion = '';

if (percentage >= 75) {
  rank = 'HIGH';
  suggestion = 'Excellent! Try advanced exams.';
} else if (percentage >= 40) {
  rank = 'MEDIUM';
  suggestion = 'Good! Practice more to improve.';
} else {
  rank = 'LOW';
  suggestion = 'Focus on basics and revise concepts.';
}


  const currentUser = JSON.parse(localStorage.getItem('user') || '{}');

  if (!currentUser.id) {
    alert("User not logged in");
    console.error("❌ USER ID MISSING");
    return;
  }

  const payload = {
    user: currentUser.id,  
    exam: this.selectedExam.id,
    score: score,
    total: totalMarks,
    percentage: percentage,
    rank: rank,
    suggestion: suggestion,
    exam_title: this.selectedExam.title,
    exam_type: this.selectedExam.difficulty,
  };

  console.log("📦 SENDING RESULT:", payload);

  this.api.addResult(payload).subscribe({
    next: (res) => {

      console.log("✅ RESULT SAVED:", res);

      this.result = res;

      this.loadResults();
      this.cd.detectChanges();
      this.markCompleted(this.selectedExam.difficulty);
    },
    error: (err) => {
      console.error("❌ RESULT ERROR:", err.error);
      // alert("Result save failed");
      alert(JSON.stringify(err.error));
  
    }
  });
}

loadResults() {
  this.api.getResults().subscribe((res: any) => {

    // this.history = res || [];
    this.history = (res || []).filter((r: any) => Number(r.user) === Number(this.userId));
    this.groupedResults = {};

    this.history.forEach((r: any) => {

      const examName = r.exam_details
        ? `${r.exam_details.difficulty} - ${r.exam_details.title}`
        : `Unknown Exam`;

      if (!this.groupedResults[examName]) {
        this.groupedResults[examName] = [];
      }

      this.groupedResults[examName].push(r);

    });

    this.cd.detectChanges();
  });
}

openResultExam(examName: string) {
  this.selectedResultExam = examName;
}

backToResultList() {
  this.selectedResultExam = null;
}

getExamNames(): string[] {
  return Object.keys(this.groupedResults);
}

  resetExam() {
    this.selectedExam = null;
    this.answers = {};
    this.result = null;

    if (this.timer) {
      clearInterval(this.timer);
    }
  }

selectMenu(menu: string) {
  this.selectedMenu = menu;
}

hasCompleted(type: string): boolean {
  return this.completedExams.includes(type);
}

markCompleted(type: string) {
  if (!this.completedExams.includes(type)) {
    this.completedExams.push(type);
  }
}

canAccessExam(type: string): boolean {

  if (type === 'Model') {
    return this.hasCompleted('Mid');
  }

  if (type === 'Final') {
    return this.hasCompleted('Mid') && this.hasCompleted('Model');
  }

  return true; 
}

isExamAvailable(exam: any): boolean {


  const restrictedTypes = ['Mid', 'Model', 'Final'];

  if (!restrictedTypes.includes(exam.difficulty)) {
    return true; 
  }

  const now = new Date();
  const examDate = new Date(exam.date);

  return now >= examDate;
}

openExamByType(type: string) {

  if (!this.canAccessExam(type)) {
    alert('Complete required exams first!');
    return;
  }

  this.filteredExamList = this.exams.filter(e => e.difficulty === type);

  this.selectedMenu = 'examList';
}



getAttemptCount(examName: string): number {
  return this.groupedResults[examName]?.length || 0;
}


getAttemptCountByExam(exam: any): number {
  return this.history.filter(
    r => Number(r.exam) === Number(exam.id)
  ).length;
}



getResultsByExam(exam: any): any[] {
  return this.history.filter(
    r => Number(r.exam) === Number(exam.id)
  );
}


getLastAttempt(exam: any): any | null {
  const attempts = this.getResultsByExam(exam);

  if (!attempts.length) return null;

  return attempts.sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  )[0];
}

isCooldownOver(lastAttempt: any): boolean {
  if (!lastAttempt) return true;

  const lastTime = new Date(lastAttempt.date).getTime();
  const now = new Date().getTime();

  const hoursPassed = (now - lastTime) / (1000 * 60 * 60);

  return hoursPassed >= 24;
}


canAttemptExam(exam: any): boolean {

  const attempts = this.getResultsByExam(exam);


  if (attempts.length >= this.maxAttempts) return false;

  const lastAttempt = this.getLastAttempt(exam);

  if (!lastAttempt) return true;

  if (lastAttempt.percentage >= 40) return false;

  if (!this.isCooldownOver(lastAttempt)) return false;

  return true;
}


getExamWiseSuggestions() {
  const grouped: any = {};

  this.history.forEach((r: any) => {

    const examName = r.exam_details
      ? `${r.exam_details.difficulty} - ${r.exam_details.title}`
      : 'Unknown Exam';

    if (!grouped[examName]) {
      grouped[examName] = [];
    }

    grouped[examName].push(r);
  });

  return grouped;
}


getLatestAttempt(results: any[]) {
  return results.sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  )[0];
}

getSuggestionText(r: any): string {

  if (r.percentage < 40) {
    return "❌ Failed → Revise basics and retry after 24 hrs";
  }

  if (r.percentage < 75) {
    return "⚠️ Average → Practice more medium-level questions";
  }

  return "✅ Excellent → Try advanced exams";
}

  // ✅ CLEANUP (IMPORTANT 🔥)
  ngOnDestroy() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }
}