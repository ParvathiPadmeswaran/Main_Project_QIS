import { Component, OnInit, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';
import { forkJoin } from 'rxjs';
import { ChangeDetectorRef } from '@angular/core';
import { Chart } from 'chart.js/auto';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-dashboard.html'
})
export class AdminDashboardComponent implements OnInit {

  selectedModule = 'analytics';

  users: any[] = [];
  exams: any[] = [];
  questions: any[] = [];

  results: any[] = [];
  filteredResults: any[] = [];
  selectedExamId: number | null = null;

  selectedExamType: string = '';
  filteredExams: any[] = [];

  dataLoaded = false;

  question: any = {
    text: '',
    options: ['', '', '', ''],
    correctAnswer: '',
    difficulty: '',
    marks: 0
  };

  exam: any = {
    title: '',
    duration: '',
    date: '',
    totalMarks: 0,
    numberOfQuestions: 0,
    difficulty: ''
  };

  filteredQuestions: any[] = [];
  selectedQuestions: any[] = [];
  chart: any;
  selectedDifficulty: string = '';

constructor(
  private api: ApiService,
  private cd: ChangeDetectorRef
) {}

  ngOnInit() {
    this.loadAllData();
  }
  
  // ================= LOAD ALL DATA =================
 loadAllData() { ///1

  this.dataLoaded = false;
  forkJoin({ //2
    users: this.api.getUsers(),
    exams: this.api.getExams(),
    questions: this.api.getQuestions(),
    results: this.api.getResults()  }) //2
    
    .subscribe({ //3

      next: (res: any) => { //4
    this.users = (res.users || []).filter((u: any) =>
        (u.role || '').toLowerCase() === 'student'
      );
      this.exams = res.exams || [];
      this.questions = res.questions || [];
      // this.filteredQuestions = this.questions; 
      this.results = res.results || [];
      this.filteredResults = this.results;
      this.dataLoaded = true; // ✅ GUARANTEED
      this.cd.detectChanges();
      this.filteredExams = this.exams;  
      
      // graph
      setTimeout(() => {//5
          if (this.selectedModule === 'analytics') {
              this.renderAnalyticsChart();
                    }
                });//5
    
      }, //4

    error: (err) => { //6
      console.error("Dashboard load error:", err);
      this.users = [];
      this.exams = [];
      this.questions = [];
      this.dataLoaded = true;
      this.cd.detectChanges();
    } //6
    
  }); //3

} //1


  deleteUser(id: number) {
    this.api.deleteUser(id).subscribe({
      next: () => {
        this.users = this.users.filter(u => u.id !== id);
      }
    });
  }

addQuestion() {

  if (
    !this.question.text ||
    this.question.options.includes('') ||
    !this.question.correctAnswer ||
    !this.question.difficulty ||
    !this.question.marks
  ) {
    alert("Fill all fields");
    return;
  }

  const payload = {
    question_text: this.question.text,

    option_a: this.question.options[0],
    option_b: this.question.options[1],
    option_c: this.question.options[2],
    option_d: this.question.options[3],

    correct_answer: this.question.correctAnswer,
    difficulty: this.question.difficulty,
    marks: Number(this.question.marks)
  };

  console.log("QUESTION PAYLOAD:", payload);

  this.api.addQuestion(payload).subscribe({
    next: () => {
      alert("Question Added");

      this.loadAllData();
      // 👇 ADD THIS
this.filterQuestionBank('All');

      this.question = {
        text: '',
        options: ['', '', '', ''],
        correctAnswer: '',
        difficulty: '',
        marks: 0
      };
    },
    error: (err) => {
      console.log("❌ QUESTION ERROR:", err.error);
    }
  });
}


deleteQuestion(id: number) {
  this.api.deleteQuestion(id).subscribe({
    next: () => {
      this.questions = this.questions.filter(q => q.id !== id);
    }
  });
}


  filterQuestions() {

  const showAllTypes = ['Practice', 'Mid', 'Model', 'Final'];

  if (showAllTypes.includes(this.exam.difficulty)) {
    this.filteredQuestions = this.questions;
  } else {
    this.filteredQuestions = this.questions.filter(
      q => q.difficulty === this.exam.difficulty
    );
  }

  this.selectedQuestions = [];
}


  toggleQuestion(q: any) {
    const exists = this.selectedQuestions.find(x => x.id === q.id);

    if (exists) {
      this.selectedQuestions = this.selectedQuestions.filter(x => x.id !== q.id);
    } else {
      this.selectedQuestions.push(q);
    }
  }

  getTotalSelectedMarks() {
    return this.selectedQuestions.reduce((sum, q) => sum + Number(q.marks), 0);
  }

createExam() {

  if (
    !this.exam.title ||
    !this.exam.duration ||
    !this.exam.date ||
    !this.exam.totalMarks ||
    !this.exam.numberOfQuestions ||
    !this.exam.difficulty
  ) {
    alert("Fill all fields!");
    return;
  }

  if (this.selectedQuestions.length !== Number(this.exam.numberOfQuestions)) {
    alert("Select correct number of questions!");
    return;
  }

  if (this.getTotalSelectedMarks() !== Number(this.exam.totalMarks)) {
    alert("Total marks mismatch!");
    return;
  }

  const payload = {
    title: this.exam.title,
    duration: this.exam.duration,
    date: this.exam.date,   
    total_marks: this.exam.totalMarks,  
    number_of_questions: this.exam.numberOfQuestions, 
    difficulty: this.exam.difficulty,
    questions: this.selectedQuestions.map(q => q.id)
  };

  console.log("🚀 SENDING:", payload); 

  this.api.addExam(payload).subscribe({
    next: () => {
      alert("✅ Exam Created Successfully");
      this.loadAllData();

      this.exam = {
        title: '',
        duration: '',
        date: '',
        totalMarks: 0,
        numberOfQuestions: 0,
        difficulty: ''
      };

      this.selectedQuestions = [];
      this.filteredQuestions = [];
       this.cd.detectChanges();
    },

    error: (err) => {
      console.log("❌ EXAM ERROR:", err.error);
      alert("Exam creation failed");
    }
  });
}

filterResultsByExam() {
  if (!this.selectedExamId) {
    this.filteredResults = this.results;
  } else {
    this.filteredResults = this.results.filter(r =>
      (r.exam?.id || r.exam) == this.selectedExamId
    );
  }
}

getAverageScore() {
  if (!this.filteredResults.length) return 0;

  const total = this.filteredResults.reduce((sum, r) => sum + r.percentage, 0);
  return (total / this.filteredResults.length).toFixed(2);
}


getPerformanceStats() {
  let high = 0, medium = 0, low = 0;

  this.filteredResults.forEach(r => {
    if (r.percentage >= 75) high++;
    else if (r.percentage >= 40) medium++;
    else low++;
  });

  return { high, medium, low };
}


getRankCounts() {
  const ranks: any = {};

  this.filteredResults.forEach(r => {
    ranks[r.rank] = (ranks[r.rank] || 0) + 1;
  });

  return ranks;
}

  deleteExam(id: number) {

     if (!confirm("Are you sure you want to delete this exam?")) {
    return;
  }
    this.api.deleteExam(id).subscribe({
      next: () => {
        this.exams = this.exams.filter(e => e.id !== id);
        this.filteredExams = this.filteredExams.filter(e => e.id !== id);
        this.cd.detectChanges();
        //  this.loadAllData();
      },
       error: () => {
      alert("Delete failed");
    }
    });
  }

  getOverallAverageScore() {
  if (!this.results.length) return 0;

  const total = this.results.reduce((sum, r) => sum + r.percentage, 0);
  return (total / this.results.length).toFixed(2);
}


getOverallPerformanceStats() {
  let high = 0, medium = 0, low = 0;

  this.results.forEach(r => {
    if (r.percentage >= 75) high++;
    else if (r.percentage >= 40) medium++;
    else low++;
  });

  return { high, medium, low };
}


renderAnalyticsChart() {

  const canvas = document.getElementById('analyticsChart') as HTMLCanvasElement;

  if (!canvas) return;

  const stats = this.getOverallPerformanceStats();

  if (this.chart) {
    this.chart.destroy();
  }

  this.chart = new Chart(canvas, {
    type: 'bar',
    data: {
      labels: ['High', 'Medium', 'Low'],
      datasets: [{
        label: 'Students Performance',
        data: [stats.high, stats.medium, stats.low]
      }]
    }
  });
}

  filterExams() {
  if (!this.selectedExamType) {
    this.filteredExams = this.exams;
  } else {
    this.filteredExams = this.exams.filter(
      e => e.difficulty === this.selectedExamType
    );
  }
}

filterQuestionBank(level: string) {

  this.selectedDifficulty = level;

  if (level === 'All') {
    this.filteredQuestions = this.questions;
  } else {
    this.filteredQuestions = this.questions.filter(
      q => (q.difficulty || '').toLowerCase() === level.toLowerCase()
    );
  }
}


  // ================= NAV =================
  selectModule(m: string) {
    this.selectedModule = m;

    if (m === 'analytics') {
    setTimeout(() => {
      this.renderAnalyticsChart();
    });
  }
  }



}
