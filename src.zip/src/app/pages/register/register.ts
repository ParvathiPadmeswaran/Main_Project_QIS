import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';
import { ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, RouterModule, CommonModule],
  templateUrl: './register.html'
})
export class RegisterComponent {

  user: any = {
    firstName: '',
    lastName: '',
    dob: '',
    email: '',
    gender: '',
    state: '',
    password: '',
    confirmPassword: '',
    role: 'student'
  };

  errorMsg = '';

constructor(
  private router: Router,
  private api: ApiService,
  private cd: ChangeDetectorRef   // 👈 ADD THIS
) {}
  
register() {

  this.errorMsg = '';

  if (!this.user.firstName || this.user.firstName.trim() === '') {
    this.errorMsg = "First name is required";
    return;
  }

  if (!this.user.lastName || this.user.lastName.trim() === '') {
    this.errorMsg = "Last name is required";
    return;
  }

  if (!this.user.dob) {
    this.errorMsg = "Date of birth is required";
    return;
  }

  if (!this.user.email || this.user.email.trim() === '') {
    this.errorMsg = "Email is required";
    return;
  }

  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(this.user.email)) {
    this.errorMsg = "Invalid email format";
    return;
  }

  if (!this.user.gender || this.user.gender.trim() === '') {
    this.errorMsg = "Please select gender";
    return;
  }

  if (!this.user.state || this.user.state.trim() === '') {
    this.errorMsg = "State is required";
    return;
  }

  if (!this.user.password) {
    this.errorMsg = "Password is required";
    return;
  }

  if (this.user.password.length < 6) {
    this.errorMsg = "Password must be at least 6 characters";
    return;
  }

  const strongPass = /^(?=.*[A-Za-z])(?=.*\d).+$/;
  if (!strongPass.test(this.user.password)) {
    this.errorMsg = "Password must contain letters and numbers";
    return;
  }

  if (!this.user.confirmPassword) {
    this.errorMsg = "Confirm your password";
    return;
  }

  if (this.user.password !== this.user.confirmPassword) {
    this.errorMsg = "Passwords do not match";
    return;
  }

  this.api.addUser({
    email: this.user.email,
    password: this.user.password,
    role: this.user.role,
    first_name: this.user.firstName,
    last_name: this.user.lastName,
    dob: this.user.dob,
    gender: this.user.gender,
    state: this.user.state
  }).subscribe({
    next: () => {
      alert("✅ Registration Successful");
      this.router.navigate(['/login']);
    },
error: (err) => {
  console.log("🔥 ERROR BODY:", err.error);

  if (err.error?.email) {
    this.errorMsg = err.error.email[0];
  } else {
    this.errorMsg = "Registration failed";
  }

  this.cd.detectChanges();
}

  });
}
}