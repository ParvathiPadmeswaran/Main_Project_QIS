import { Component} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-change-password',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './change-password.html'
})
export class ChangePasswordComponent {

  oldPassword = '';
  newPassword = '';
  confirmPassword = '';
  errors: any = {};

  constructor(private api: ApiService, private router: Router ) {
    
  }

  changePassword() {

  if (!this.oldPassword || !this.newPassword || !this.confirmPassword) {
    alert("All fields are required");
    return;
  }

  if (this.newPassword.length < 6) {
    alert("Password must be at least 6 characters");
    return;
  }

  if (this.newPassword !== this.confirmPassword) {
    alert("Passwords do not match");
    return;
  }

  const currentUser = JSON.parse(localStorage.getItem('user') || '{}');

  const payload = {
    user: currentUser.id,
    old_password: this.oldPassword,
    new_password: this.newPassword
  };

  this.api.changePassword(payload).subscribe({
    next: () => {
      alert("✅ Password changed successfully");
       this.router.navigate(['/student']);
    },
    error: (err) => {
      console.log(err);

      if (err.error?.error) {
        alert(err.error.error);   // 🔥 MAIN FIX
      } else {
        alert("❌ Failed");
      }
    }
  });
}
}