import { Component } from '@angular/core';
import { RouterOutlet, RouterModule } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterModule],   // ✅ ADD RouterModule
  templateUrl: './app.html'
})
export class AppComponent {}