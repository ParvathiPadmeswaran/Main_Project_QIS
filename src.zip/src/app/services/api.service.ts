import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  baseUrl = 'http://127.0.0.1:8000/api/';

  constructor(private http: HttpClient) {}

  getUsers() {
    return this.http.get(this.baseUrl + 'users/');
  }

  addUser(user: any) {
    return this.http.post(this.baseUrl + 'users/', user);
  }

  deleteUser(id: number) {
    return this.http.delete(this.baseUrl + 'users/' + id + '/');
  }

 getQuestions() {
  return this.http.get('http://127.0.0.1:8000/api/questions/');
}

addQuestion(data: any) {
  return this.http.post('http://127.0.0.1:8000/api/questions/', data);
}

deleteQuestion(id: number) {
  return this.http.delete(`http://127.0.0.1:8000/api/questions/${id}/`);
}
 
  getExams() {
    return this.http.get(this.baseUrl + 'exams/');
  }

  addExam(exam: any) {
    return this.http.post(this.baseUrl + 'exams/', exam);
  }

  deleteExam(id: number) {
    return this.http.delete(this.baseUrl + 'exams/' + id + '/');
  }

addResult(data: any) {
  return this.http.post('http://127.0.0.1:8000/api/results/', data);
}

getResults() {
  return this.http.get('http://127.0.0.1:8000/api/results/');
}

changePassword(data: any) {
  return this.http.post(`${this.baseUrl}change-password/`, data);
}

updateUser(id: number, data: any) {
  return this.http.put(`${this.baseUrl}users/${id}/`, data);
}

}

