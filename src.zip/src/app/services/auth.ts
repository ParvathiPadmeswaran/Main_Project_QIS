import { HttpClient } from '@angular/common/http';

export class AuthService {
  apiUrl = 'http://127.0.0.1:8000/api/';

  constructor(private http: HttpClient) {}

  register(user: any) {
    return this.http.post(this.apiUrl + 'users/', user);
  }

  login(user: any) {
    return this.http.get<any[]>(this.apiUrl + 'users/');
  }
}