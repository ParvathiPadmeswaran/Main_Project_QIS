import { Component } from '@angular/core';
import { RouterOutlet, RouterModule, Router, NavigationEnd } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ApiService } from './services/api.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterModule, CommonModule],
  templateUrl: './app.html'
})
export class AppComponent {

  currentUser: any = null;
  currentRoute: string = '';

constructor(
  private router: Router,
  private api: ApiService   // ✅ ADD THIS
) {

  this.router.events.subscribe(event => {
    if (event instanceof NavigationEnd) {
      this.currentRoute = this.router.url;
      this.loadUser();
    }
  });
}

  loadUser() {
    const data = localStorage.getItem('user');   // 🔥 FIXED
    this.currentUser = data ? JSON.parse(data) : null;
  }


  logout() {
    localStorage.removeItem('user');   // 🔥 FIXED
    this.currentUser = null;
    this.router.navigate(['/login']);
  }


  isPublicPage(): boolean {
    return ['/', '/login', '/register'].includes(this.currentRoute);
  }

goToChangePassword(){
  this.router.navigate(['/change-password']);
}

goToProfile() {
  this.router.navigate(['/profile']);
}

goHome() {
  if (!this.currentUser) return;

  if (this.currentUser.role === 'student') {
    this.router.navigate(['/student']);
  } 
  else if (this.currentUser.role === 'admin') {
    this.router.navigate(['/admin']);
  } 
  else {
    this.router.navigate(['/']);
  }
}

}